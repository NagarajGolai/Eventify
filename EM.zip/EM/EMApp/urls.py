from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signin/', views.signin, name='signin'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.logout, name='logout'),
    path('codeginger02/unapproved-users/', views.show_unapproved_users, name='show_unapproved_users'),
    path('codeginger02/send-emails/', views.send_confirmation_emails, name='send_confirmation_emails'),
    path('activate/<str:token>/', views.activate_account, name='activate_account'),
    path('email-verification/<int:user_id>/', views.email_verification, name='email_verification'),
    path('resend-verification/<int:user_id>/', views.resend_verification_email, name='resend_verification_email'),
    path('loggedin/', views.loggedin, name='loggedin'),
    path('loggedin/active-members/', views.active_members, name='active_members'),
    
    # Event Management URLs
    path('events/', views.event_list, name='event_list'),
    path('events/create/', views.create_event, name='create_event'),
    path('events/<int:event_id>/', views.event_detail, name='event_detail'),
    path('events/<int:event_id>/edit/', views.edit_event, name='edit_event'),
    path('events/<int:event_id>/delete/', views.delete_event, name='delete_event'),
    path('events/<int:event_id>/rsvp/', views.rsvp_event, name='rsvp_event'),
    path('events/<int:event_id>/attendees/', views.event_attendees, name='event_attendees'),
    path('my-events/', views.my_events, name='my_events'),
    path('ticket/<uuid:ticket_id>/', views.ticket_detail, name='ticket_detail'),
    path('ticket/<uuid:ticket_id>/qr/', views.ticket_qr_code, name='ticket_qr_code'),
    path('ticket/<uuid:ticket_id>/send_email/', views.send_ticket_email, name='send_ticket_email'),
    path('ticket/emailed/success/<str:email>/', views.ticket_emailed_success, name='ticket_emailed_success'),
    path('events/<int:event_id>/export_attendees_csv/', views.export_attendees_csv, name='export_attendees_csv'),

    # path('loggedin/news/', views.news_for_members, name='news_for_members'),
]
