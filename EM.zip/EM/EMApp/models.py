from django.db import models
from django.utils import timezone
import uuid
import qrcode
from io import BytesIO
from django.core.files import File
import os

# Create your models here.
class Member(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField()
    password1 = models.CharField(max_length=100)
    password2 = models.CharField(max_length=100)
    is_approved = models.BooleanField(default=False)
    activation_token = models.CharField(max_length=100, blank=True, null=True)
    is_activated = models.BooleanField(default=False)

    def __str__(self):
        return self.username

class Event(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateTimeField()
    location = models.CharField(max_length=200)
    organizer = models.ForeignKey(Member, on_delete=models.CASCADE, related_name='organized_events')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    max_attendees = models.PositiveIntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.title

    @property
    def attendee_count(self):
        return self.rsvps.filter(status='confirmed').count()

    @property
    def is_full(self):
        if self.max_attendees:
            return self.attendee_count >= self.max_attendees
        return False

class RSVP(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
    ]
    
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='rsvps')
    attendee = models.ForeignKey(Member, on_delete=models.CASCADE, related_name='rsvps')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['event', 'attendee']  # Prevent duplicate RSVPs

    def __str__(self):
        return f"{self.attendee.username} - {self.event.title}"

import uuid
from django.db import models
from django.core.files.base import File
from io import BytesIO
import qrcode

class Ticket(models.Model):
    ticket_id = models.UUIDField(default=uuid.uuid4, unique=True)
    rsvp = models.OneToOneField('RSVP', on_delete=models.CASCADE, related_name='ticket')
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True, null=True)

    def generate_qr_code(self):
        qr = qrcode.make(f"http://example.com/ticket/{self.ticket_id}/")
        buffer = BytesIO()
        qr.save(buffer, format='PNG')
        filename = f"qr_code_{self.ticket_id}.png"
        self.qr_code.save(filename, File(buffer), save=False)  # Save to field but don't commit yet
        buffer.close()

    def save(self, *args, **kwargs):
        regenerate = False
        if not self.qr_code:
            regenerate = True
        else:
            try:
                if not os.path.exists(self.qr_code.path):
                    regenerate = True
                else:
                    with open(self.qr_code.path, 'rb') as f:
                        header = f.read(8)
                        if header != b'\x89PNG\r\n\x1a\n':
                            regenerate = True
            except Exception:
                regenerate = True

        # If we need to generate the QR code, do it before saving
        if regenerate:
            qr = qrcode.make(f"http://example.com/ticket/{self.ticket_id}/")
            buffer = BytesIO()
            qr.save(buffer, format='PNG')
            filename = f"qr_code_{self.ticket_id}.png"
            self.qr_code.save(filename, File(buffer), save=False)
            buffer.close()

        super().save(*args, **kwargs)