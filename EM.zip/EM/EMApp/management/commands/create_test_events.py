from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from EMApp.models import Event, Member

class Command(BaseCommand):
    help = 'Create test events for development'

    def handle(self, *args, **options):
        # Get or create a test user
        test_user, created = Member.objects.get_or_create(
            username='testuser',
            defaults={
                'email': 'test@example.com',
                'password1': 'testpass123',
                'password2': 'testpass123',
                'is_activated': True,
                'is_approved': True
            }
        )
        
        if created:
            self.stdout.write(f'Created test user: {test_user.username}')
        else:
            self.stdout.write(f'Using existing test user: {test_user.username}')

        # Create test events
        events_data = [
            {
                'title': 'Tech Meetup 2024',
                'description': 'Join us for an exciting tech meetup where we\'ll discuss the latest trends in web development, AI, and cloud computing. Network with fellow developers and learn from industry experts.',
                'date': timezone.now() + timedelta(days=7),
                'location': 'Tech Hub Downtown, 123 Innovation Street',
                'max_attendees': 50
            },
            {
                'title': 'Music Festival',
                'description': 'A fantastic music festival featuring local bands and artists. Enjoy live music, food trucks, and great company. Don\'t miss this amazing event!',
                'date': timezone.now() + timedelta(days=14),
                'location': 'Central Park, Main Stage',
                'max_attendees': 200
            },
            {
                'title': 'Business Networking Event',
                'description': 'Connect with entrepreneurs, investors, and business professionals. Share ideas, build partnerships, and grow your network in a relaxed atmosphere.',
                'date': timezone.now() + timedelta(days=3),
                'location': 'Business Center, Conference Room A',
                'max_attendees': 30
            },
            {
                'title': 'Cooking Workshop',
                'description': 'Learn to cook delicious Italian cuisine from our expert chef. Hands-on cooking experience with all ingredients provided. Take home recipes and new skills!',
                'date': timezone.now() + timedelta(days=10),
                'location': 'Culinary Institute, Kitchen Studio',
                'max_attendees': 15
            },
            {
                'title': 'Fitness Bootcamp',
                'description': 'High-intensity workout session led by certified trainers. Suitable for all fitness levels. Get ready to sweat and have fun!',
                'date': timezone.now() + timedelta(days=5),
                'location': 'Fitness Center, Main Gym',
                'max_attendees': 25
            }
        ]

        created_events = []
        for event_data in events_data:
            event, created = Event.objects.get_or_create(
                title=event_data['title'],
                defaults={
                    'description': event_data['description'],
                    'date': event_data['date'],
                    'location': event_data['location'],
                    'organizer': test_user,
                    'max_attendees': event_data['max_attendees'],
                    'is_active': True
                }
            )
            
            if created:
                created_events.append(event)
                self.stdout.write(f'Created event: {event.title}')
            else:
                self.stdout.write(f'Event already exists: {event.title}')

        self.stdout.write(
            self.style.SUCCESS(f'Successfully created {len(created_events)} test events!')
        ) 