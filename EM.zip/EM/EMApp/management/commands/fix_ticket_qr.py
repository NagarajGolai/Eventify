from django.core.management.base import BaseCommand
from EMApp.models import Ticket

class Command(BaseCommand):
    help = 'Regenerate QR codes for all tickets.'

    def handle(self, *args, **options):
        count = 0
        for ticket in Ticket.objects.all():
            ticket.save()
            count += 1
        self.stdout.write(self.style.SUCCESS(f'Regenerated QR codes for {count} tickets.')) 