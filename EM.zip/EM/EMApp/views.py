from django.shortcuts import render, HttpResponse
from django.contrib.auth.models import User
from django.shortcuts import redirect
from django.contrib import messages
from datetime import datetime
from EMApp.models import Member
from django.contrib.auth import authenticate, login
from django.http import JsonResponse, FileResponse, Http404
from django.utils import timezone
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from .models import Event, RSVP, Ticket
from django.core.mail import EmailMessage, EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
import os
from django.views.decorators.http import require_POST
from django.http import HttpResponseRedirect
from email.mime.image import MIMEImage
from django.db import models
import csv


def index(request):
    # If user is logged in, redirect to dashboard
    if request.session.get('user_id'):
        return redirect('loggedin')
    
    # Get real statistics from the database
    from .models import Event, Member, Ticket
    
    stats = {
        'events_hosted': Event.objects.count(),
        'users_joined': Member.objects.filter(is_activated=True).count(),
        'tickets_issued': Ticket.objects.count(),
    }
    
    return render(request, 'index.html', {'stats': stats})

def loggedin(request):
    return render(request, 'loggedin.html')

# views.py
from django.shortcuts import render

def active_members(request):
    active_members_list = Member.objects.filter(is_active=True)  # Fetch active members
    return render(request, 'active_members.html', {'members': active_members_list})

def signin(request):
    print(f"Request method: {request.method}")
    print(f"CSRF token in request: {'csrfmiddlewaretoken' in request.POST}")
    
    if request.method == 'POST':
        email = request.POST.get('email')  # Get email from the form
        password = request.POST.get('password')  # Get password from the form

        try:
            # Check if the user exists in the database
            user = Member.objects.get(email=email)

            # Verify password and active status
            if user.password1 == password:
                if user.is_activated:  # Correct field name
                    messages.success(request, f'Welcome back, {user.username}!')
                    # Store user_id in session for authentication
                    request.session['user_id'] = user.id
                    return redirect('loggedin')  # Redirect to the dashboard
                else:
                    messages.error(request, 'Your account is not active. Please check you e-mail to activate it!')
            else:
                messages.error(request, 'Invalid credentials. Please try again.')

        except Member.DoesNotExist:
            messages.error(request, 'User not found. Please sign up first.')

        
        return render(request, 'signin.html')

    # For GET requests, render the index page with signin modal open
    return render(request, 'index.html')

@csrf_exempt
def signup(request):
    print(f"Request method: {request.method}")
    print(f"CSRF token in request: {'csrfmiddlewaretoken' in request.POST}")
    print(f"Request headers: {dict(request.headers)}")
    print(f"Request META: {dict(request.META)}")
    
    if request.method == 'POST':
        # Check CSRF token explicitly
        from django.middleware.csrf import get_token
        
        # Get the current CSRF token
        csrf_token = get_token(request)
        print(f"Generated CSRF token: {csrf_token}")
        print(f"POST CSRF token: {request.POST.get('csrfmiddlewaretoken')}")
        print(f"CSRF cookie: {request.META.get('CSRF_COOKIE')}")
        print(f"CSRF cookie name: {request.META.get('CSRF_COOKIE_NAME')}")
        
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        print(f"Form data - username: {username}, email: {email}")
        print(f"All POST data: {dict(request.POST)}")
        print(f"Password1: {password1}")
        print(f"Password2: {password2}")

        # Check if passwords match
        if password1 != password2:
            print("DEBUG: Passwords do not match")
            messages.error(request, "Passwords do not match!")
            return render(request, 'signup.html')
        
        # Check if user with same username already exists
        if Member.objects.filter(username=username).exists():
            print("DEBUG: Username already exists")
            messages.error(request, "A user with this username already exists!")
            return render(request, 'signup.html')
        
        # Check if user with same email already exists
        if Member.objects.filter(email=email).exists():
            print("DEBUG: Email already exists")
            messages.error(request, "A user with this email already exists!")
            return render(request, 'signup.html')

        print("DEBUG: All validations passed, creating user...")
        # If all checks pass, create the new user
        try:
            activation_token = generate_activation_token()
            member = Member(
                username=username,
                email=email,
                password1=password1,
                password2=password2,
                activation_token=activation_token
            )
            member.save()
            print(f"DEBUG: User created with ID: {member.id}")

            send_activation_email(member)  # Send activation email
            messages.success(request, 'You have signed up! Please check your email to activate your account.')
            
            print("DEBUG: Redirecting to email verification...")
            print(f"DEBUG: Redirect URL: /email-verification/{member.id}/")
            # Don't auto-login - require email verification first
            return redirect(f'/email-verification/{member.id}/')
        except Exception as e:
            print(f"DEBUG: Exception occurred: {e}")
            messages.error(request, f'An error occurred during signup: {e}')
            return render(request, 'signup.html')
    
    # For GET requests, render the signup page
    return render(request, 'signup.html')

# def signin_modal(request):
#     """Handle signin form submission from the home page modal"""
#     if request.method == 'POST':
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         
#         print(f"Signin modal - Email: {email}")
#         print(f"Signin modal - Password: {password}")
#         
#         try:
#             member = Member.objects.get(email=email)
#             print(f"Signin modal - Member found: {member.username}")
#             print(f"Signin modal - Member is_active: {member.is_active}")
#             print(f"Signin modal - Password match: {member.password1 == password}")
#             
#             if member.password1 == password:
#                 if member.is_active:
#                     request.session['user_id'] = member.id
#                     print(f"Signin modal - Session set: {request.session['user_id']}")
#                     messages.success(request, f'Welcome back, {member.username}!')
#                     return redirect('loggedin')
#                 else:
#                     print("Signin modal - Account not active")
#                     messages.error(request, 'Your account is not active. Please check your email to activate it!')
#                     return redirect('index')
#             else:
#                 print("Signin modal - Password mismatch")
#                 messages.error(request, 'Invalid email or password!')
#                 return redirect('index')
#         except Member.DoesNotExist:
#             print("Signin modal - Member not found")
#             messages.error(request, 'Invalid email or password!')
#             return redirect('index')
#     
#     # For GET requests, redirect to home
#     return redirect('index')

# Email Confirmation
from django.core.mail import send_mail
from django.conf import settings
from django.utils.crypto import get_random_string

def generate_activation_token():
    return get_random_string(length=32)

def send_activation_email(user):
    activation_link = f"http://127.0.0.1:8000/activate/{user.activation_token}/"  # Update with your domain
    subject = "Activate Your Account"
    message = f"Hi {user.username},\nClick the link below to activate your account:\n{activation_link}\n\nThank you!\n\n"
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [user.email]
    send_mail(subject, message, from_email, recipient_list)

# Admin's interface

def show_unapproved_users(request):
    unapproved_users = Member.objects.filter(is_active=False)
    return render(request, "approve_users.html", {"users": unapproved_users})

def send_confirmation_emails(request):
    if request.method == "POST":
        user_ids = request.POST.getlist("user_ids")
        selected_users = Member.objects.filter(id__in=user_ids, is_active=False)

        for user in selected_users:
            user.activation_token = generate_activation_token()
            user.save()
            send_activation_email(user)

        messages.success(request,  f"{len(selected_users)} users have been successfully informed via email. Hope they login soon to check out!")
        # return redirect('email_sent')
        return JsonResponse({"message": f"{len(selected_users)} users have been successfully informed via email. Hope they login soon to check out!"})
    # return render(request, "email_sent.html")
    return JsonResponse({"error": "Invalid request method."}, status=400)

#Action view
def activate_account(request, token):
    try:
        user = Member.objects.get(activation_token=token)
        if user.is_activated:
            return render(request, 'activation_success.html', {
                'user': user,
                'message': 'Your account is already activated. Please login.',
                'status': 'already_active'
            })
        user.is_activated = True
        user.activation_token = None
        user.save()
        return render(request, 'activation_success.html', {
            'user': user,
            'message': 'Your account has been successfully verified!',
            'status': 'success'
        })
    except Member.DoesNotExist:
        return render(request, 'activation_success.html', {
            'message': 'Invalid or expired activation link.',
            'status': 'error'
        })

def email_verification(request, user_id):
    """Show email verification page after signup"""
    print(f"DEBUG: email_verification called with user_id: {user_id}")
    try:
        user = Member.objects.get(id=user_id)
        print(f"DEBUG: User found: {user.username}")
        return render(request, 'email_verification.html', {'user': user})
    except Member.DoesNotExist:
        print(f"DEBUG: User with ID {user_id} not found")
        messages.error(request, 'User not found.')
        return redirect('index')

def resend_verification_email(request, user_id):
    """Resend verification email"""
    try:
        user = Member.objects.get(id=user_id)
        if user.is_activated:
            messages.info(request, 'Your account is already activated.')
            return redirect('signin')
        
        # Generate new activation token
        user.activation_token = generate_activation_token()
        user.save()
        
        # Resend activation email
        send_activation_email(user)
        messages.success(request, 'Verification email has been resent! Please check your inbox.')
        return redirect('email_verification', user_id=user.id)
        
    except Member.DoesNotExist:
        messages.error(request, 'User not found.')
        return redirect('index')

# Event Management Views
def event_list(request):
    """Display a list of all active events, including those hosted by the current user, with search and filtering."""
    if not request.session.get('user_id'):
        messages.error(request, 'Please log in to browse events.')
        return redirect('signin')

    events = Event.objects.filter(is_active=True).order_by('date')

    # --- Filtering logic ---
    search_query = request.GET.get('search', '').strip()
    date_query = request.GET.get('date', '').strip()
    location_query = request.GET.get('location', '').strip()
    category_query = request.GET.get('category', '').strip()

    if search_query:
        events = events.filter(
            models.Q(title__icontains=search_query) |
            models.Q(description__icontains=search_query)
        )
    if date_query:
        events = events.filter(date__date=date_query)
    if location_query:
        events = events.filter(location__icontains=location_query)
    if hasattr(Event, 'category') and category_query:
        events = events.filter(category__iexact=category_query)

    try:
        current_user = Member.objects.get(id=request.session['user_id'])
    except Member.DoesNotExist:
        current_user = None
    user_rsvps = {}
    if current_user:
        rsvps = RSVP.objects.filter(attendee=current_user, event__in=events)
        for rsvp in rsvps:
            user_rsvps[rsvp.event_id] = rsvp
    return render(request, 'events/event_list.html', {
        'events': events,
        'current_user': current_user,
        'user_rsvps': user_rsvps,
        'search_query': search_query,
        'date_query': date_query,
        'location_query': location_query,
        'category_query': category_query,
    })

def event_detail(request, event_id):
    if not request.session.get('user_id'):
        messages.error(request, 'Please log in to view event details.')
        return redirect('signin')
    event = get_object_or_404(Event, id=event_id, is_active=True)
    user_rsvp = None
    current_user = None
    if request.session.get('user_id'):
        try:
            current_user = Member.objects.get(id=request.session['user_id'])
            user_rsvp = RSVP.objects.filter(event=event, attendee=current_user).first()
        except Member.DoesNotExist:
            pass
    context = {
        'event': event,
        'user_rsvp': user_rsvp,
        'current_user': current_user,
        'attendees': event.rsvps.filter(status='confirmed')
    }
    return render(request, 'events/event_detail.html', context)

def create_event(request):
    """Allow authenticated users to create events"""
    # Check authentication for both GET and POST requests
    if not request.session.get('user_id'):
        messages.error(request, 'You must be logged in to create events.')
        return redirect('signin')
    
    if request.method == 'POST':
        try:
            organizer = Member.objects.get(id=request.session['user_id'])
            
            # Parse the datetime and make it timezone-aware
            event_datetime = datetime.strptime(request.POST.get('date'), '%Y-%m-%dT%H:%M')
            event_datetime = timezone.make_aware(event_datetime)
            
            print(f"Creating event with datetime: {event_datetime}")
            print(f"Current timezone: {timezone.get_current_timezone()}")
            
            event = Event(
                title=request.POST.get('title'),
                description=request.POST.get('description'),
                date=event_datetime,
                location=request.POST.get('location'),
                organizer=organizer,
                max_attendees=request.POST.get('max_attendees') or None
            )
            event.save()
            
            print(f"Event created: {event.title}, Date: {event.date}, Active: {event.is_active}")
            
            messages.success(request, 'Event created successfully!')
            return redirect('event_detail', event_id=event.id)
            
        except (Member.DoesNotExist, ValueError) as e:
            print(f"Error creating event: {e}")
            messages.error(request, 'Error creating event. Please try again.')
            return redirect('create_event')
    
    return render(request, 'events/create_event.html')

def edit_event(request, event_id):
    """Allow organizers to edit their events"""
    event = get_object_or_404(Event, id=event_id)
    
    if not request.session.get('user_id') or event.organizer.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to edit this event.')
        return redirect('event_detail', event_id=event.id)
    
    if request.method == 'POST':
        event.title = request.POST.get('title')
        event.description = request.POST.get('description')
        # Parse the datetime and make it timezone-aware
        event_datetime = datetime.strptime(request.POST.get('date'), '%Y-%m-%dT%H:%M')
        event.date = timezone.make_aware(event_datetime)
        event.location = request.POST.get('location')
        event.max_attendees = request.POST.get('max_attendees') or None
        event.save()
        
        messages.success(request, 'Event updated successfully!')
        return redirect('event_detail', event_id=event.id)
    
    return render(request, 'events/edit_event.html', {'event': event})

def delete_event(request, event_id):
    """Allow organizers to delete their events"""
    event = get_object_or_404(Event, id=event_id)
    
    if not request.session.get('user_id') or event.organizer.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to delete this event.')
        return redirect('event_detail', event_id=event.id)
    
    if request.method == 'POST':
        event.delete()
        messages.success(request, 'Event deleted successfully!')
        return redirect('event_list')
    
    return render(request, 'events/delete_event.html', {'event': event})

def rsvp_event(request, event_id):
    """Handle RSVP functionality"""
    if not request.session.get('user_id'):
        messages.error(request, 'You must be logged in to RSVP for events.')
        return redirect('signin')
    
    event = get_object_or_404(Event, id=event_id, is_active=True)
    user = get_object_or_404(Member, id=request.session['user_id'])
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'rsvp':
            if event.is_full:
                messages.error(request, 'This event is full.')
                return redirect('event_detail', event_id=event.id)
            
            rsvp, created = RSVP.objects.get_or_create(
                event=event,
                attendee=user,
                defaults={'status': 'confirmed'}
            )
            
            if not created:
                rsvp.status = 'confirmed'
                rsvp.save()
            
            # Generate ticket
            ticket, ticket_created = Ticket.objects.get_or_create(rsvp=rsvp)
            
            messages.success(request, 'RSVP successful! Your ticket has been generated.')
            
            # Send ticket email
            send_ticket_email_util(ticket)
            
        elif action == 'cancel':
            try:
                rsvp = RSVP.objects.get(event=event, attendee=user)
                rsvp.status = 'cancelled'
                rsvp.save()
                messages.success(request, 'RSVP cancelled successfully.')
            except RSVP.DoesNotExist:
                messages.error(request, 'No RSVP found for this event.')
    
    return redirect('event_detail', event_id=event.id)

def my_events(request):
    """Show user's organized events and RSVPs"""
    if not request.session.get('user_id'):
        messages.error(request, 'You must be logged in to view your events.')
        return redirect('signin')
    
    user = get_object_or_404(Member, id=request.session['user_id'])
    
    # Get events organized by the user
    hosted_events = Event.objects.filter(organizer=user).order_by('-created_at')
    
    # Get events the user has RSVP'd to
    user_rsvps = RSVP.objects.filter(attendee=user, status='confirmed').select_related('event').order_by('event__date')
    
    # Calculate statistics
    total_attendees = sum(event.attendee_count for event in hosted_events)
    upcoming_events = hosted_events.filter(date__gte=timezone.now())
    past_events = hosted_events.filter(date__lt=timezone.now())
    
    context = {
        'hosted_events': hosted_events,
        'user_rsvps': user_rsvps,
        'total_attendees': total_attendees,
        'upcoming_events': upcoming_events,
        'past_events': past_events,
        'now': timezone.now(),  # For date comparison in template
    }
    return render(request, 'events/my_events.html', context)

def event_attendees(request, event_id):
    """Show list of attendees for an event (organizer only)"""
    event = get_object_or_404(Event, id=event_id)
    
    if not request.session.get('user_id') or event.organizer.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to view attendees for this event.')
        return redirect('event_detail', event_id=event.id)
    
    attendees = event.rsvps.filter(status='confirmed').select_related('attendee')
    context = {
        'event': event,
        'attendees': attendees
    }
    return render(request, 'events/event_attendees.html', context)

def ticket_detail(request, ticket_id):
    """Show ticket details"""
    ticket = get_object_or_404(Ticket, ticket_id=ticket_id)
    
    if not request.session.get('user_id') or ticket.rsvp.attendee.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to view this ticket.')
        return redirect('event_list')
    
    # Debug: Check QR code status
    print(f"DEBUG: Ticket ID: {ticket.ticket_id}")
    print(f"DEBUG: QR code field: {ticket.qr_code}")
    print(f"DEBUG: QR code URL: {ticket.qr_code.url if ticket.qr_code else 'None'}")
    print(f"DEBUG: QR code path: {ticket.qr_code.path if ticket.qr_code else 'None'}")
    if ticket.qr_code:
        print(f"DEBUG: QR code file exists: {os.path.exists(ticket.qr_code.path)}")
    
    return render(request, 'events/ticket_detail.html', {'ticket': ticket})

def logout(request):
    """Handle user logout"""
    if request.session.get('user_id'):
        del request.session['user_id']
        messages.success(request, 'You have been successfully logged out.')
    return redirect('index')

def send_ticket_email_util(ticket):
    try:
        subject = f'Your Ticket for {ticket.rsvp.event.title}'
        context = {
            'ticket': ticket,
            'event': ticket.rsvp.event,
            'attendee': ticket.rsvp.attendee,
        }
        html_message = render_to_string('emails/ticket_email.html', context)
        email = EmailMultiAlternatives(
            subject=subject,
            body='Your ticket is attached below.',
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[ticket.rsvp.attendee.email],
        )
        email.attach_alternative(html_message, "text/html")
        if ticket.qr_code and os.path.exists(ticket.qr_code.path):
            with open(ticket.qr_code.path, 'rb') as f:
                img_data = f.read()
                # Attach as inline image
                img = MIMEImage(img_data)
                img.add_header('Content-ID', f'<qr_code_{ticket.ticket_id}.png>')
                img.add_header('Content-Disposition', 'inline', filename=f'qr_code_{ticket.ticket_id}.png')
                email.attach(img)
            # Attach as downloadable file
            email.attach(f'qr_code_{ticket.ticket_id}.png', img_data, 'image/png')
        email.send()
        return True
    except Exception as e:
        print(f"Error sending ticket email: {e}")
        return False

def ticket_qr_code(request, ticket_id):
    ticket = get_object_or_404(Ticket, ticket_id=ticket_id)
    if not ticket.qr_code or not os.path.exists(ticket.qr_code.path):
        raise Http404("QR code not found")
    return FileResponse(open(ticket.qr_code.path, 'rb'), content_type='image/png')

def send_ticket_email(request, ticket_id):
    print("DEBUG: send_ticket_email view called")
    ticket = get_object_or_404(Ticket, ticket_id=ticket_id)
    if not request.session.get('user_id') or ticket.rsvp.attendee.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to email this ticket.')
        return redirect('event_list')
    if request.method == 'POST':
        print("DEBUG: POST request received, sending email...")
        send_ticket_email_util(ticket)
        # Redirect to success page with attendee email
        return redirect('ticket_emailed_success', email=ticket.rsvp.attendee.email)
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

def ticket_emailed_success(request, email):
    return render(request, 'ticket_emailed_success.html', {'email': email})

def export_attendees_csv(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if not request.session.get('user_id') or event.organizer.id != request.session['user_id']:
        messages.error(request, 'You are not authorized to export attendees for this event.')
        return redirect('event_detail', event_id=event.id)
    attendees = event.rsvps.filter(status='confirmed').select_related('attendee')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="attendees_{event_id}.csv"'
    writer = csv.writer(response)
    writer.writerow(['Username', 'Email'])
    for rsvp in attendees:
        writer.writerow([rsvp.attendee.username, rsvp.attendee.email])
    return response

