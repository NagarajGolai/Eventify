#!/usr/bin/env python
"""
Deployment script for Eventify on PythonAnywhere
"""

import os
import sys
import subprocess

def run_command(command):
    """Run a command and return the result"""
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {command}")
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"❌ {command}")
        print(f"Error: {e.stderr}")
        return None

def main():
    print("🚀 Eventify Deployment Script")
    print("=" * 40)
    
    # Check if we're in the right directory
    if not os.path.exists('manage.py'):
        print("❌ Please run this script from the project root directory")
        sys.exit(1)
    
    # Collect static files
    print("\n📦 Collecting static files...")
    run_command("python manage.py collectstatic --noinput")
    
    # Run migrations
    print("\n🗄️ Running database migrations...")
    run_command("python manage.py migrate")
    
    # Check for any issues
    print("\n🔍 Checking for potential issues...")
    
    # Check if DEBUG is False in production settings
    if os.path.exists('EM/settings_production.py'):
        with open('EM/settings_production.py', 'r') as f:
            content = f.read()
            if 'DEBUG = True' in content:
                print("⚠️  Warning: DEBUG is still True in production settings")
            else:
                print("✅ DEBUG is properly set to False")
    
    print("\n🎉 Deployment preparation complete!")
    print("\nNext steps:")
    print("1. Upload your code to PythonAnywhere")
    print("2. Set up your virtual environment")
    print("3. Configure your web app")
    print("4. Update your WSGI file")
    print("5. Reload your web app")
    print("\nSee DEPLOYMENT_GUIDE.md for detailed instructions")

if __name__ == "__main__":
    main() 