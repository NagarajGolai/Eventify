// Clean & Aesthetic JavaScript for Eventify - Bubble Theme

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initBubbles();
    initCursorBubble();
    initScrollAnimations();
    initFormValidation();
    initInteractiveEffects();
    initNavigation();
});

// Clean Bubble Animation
function initBubbles() {
    const bubblesContainer = document.getElementById('bubbles');
    if (!bubblesContainer) return;

    // Check if we should show bubbles on this page
    const currentPath = window.location.pathname;
    const excludedPages = [
        '/my_events/', 
        '/create_event/', 
        '/events/create/',
        '/my-events/',
        '/events/',
        '/edit/',
        '/delete/',
        '/rsvp/',
        '/attendees/',
        '/ticket/'
    ];
    const shouldShowBubbles = !excludedPages.some(page => currentPath.includes(page));
    
    if (!shouldShowBubbles) {
        // Hide bubbles container on excluded pages
        bubblesContainer.style.display = 'none';
        return;
    }

    // Create initial bubbles
    for (let i = 0; i < 15; i++) {
        createBubble();
    }

    // Create new bubbles periodically
    setInterval(createBubble, 1000);

    function createBubble() {
        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        
        // Random size between 20px and 80px
        const size = Math.random() * 100 + 30;
        bubble.style.width = size + 'px';
        bubble.style.height = size + 'px';
        
        // Random position
        bubble.style.left = Math.random() * 100 + '%';
        
        // Random animation duration between 20s and 30s
        const duration = Math.random() * 10 + 20;
        bubble.style.animationDuration = duration + 's';
        
        // Random delay
        bubble.style.animationDelay = Math.random() * 5 + 's';
        
        bubblesContainer.appendChild(bubble);
        
        // Remove bubble after animation
        setTimeout(() => {
            if (bubble.parentNode) {
                bubble.parentNode.removeChild(bubble);
            }
        }, duration * 1000);
    }
}

// Clean Cursor Bubble Effect
function initCursorBubble() {
    const cursorBubble = document.createElement('div');
    cursorBubble.className = 'cursor-bubble';
    document.body.appendChild(cursorBubble);

    let mouseX = 0;
    let mouseY = 0;
    let cursorX = 0;
    let cursorY = 0;

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    function animateCursor() {
        // Faster cursor following for better responsiveness
        cursorX += (mouseX - cursorX) * 0.3; // Increased from 0.1 to 0.3
        cursorY += (mouseY - cursorY) * 0.3; // Increased from 0.1 to 0.3
        
        cursorBubble.style.left = cursorX - 15 + 'px';
        cursorBubble.style.top = cursorY - 15 + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    
    animateCursor();

    // Hide cursor bubble on mobile
    if (window.innerWidth <= 768) {
        cursorBubble.style.display = 'none';
    }
}

// Clean Scroll Animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for scroll animations
    const animatedElements = document.querySelectorAll('.nav-card, .feature-card, .event-card, .user-card, .stat-card, .ticket-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Clean Form Validation
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            // Real-time validation
            input.addEventListener('blur', validateField);
            input.addEventListener('input', clearError);
            
            // Add focus effects
            input.addEventListener('focus', () => {
                input.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', () => {
                input.parentElement.classList.remove('focused');
            });
        });
        
        // Form submission
        form.addEventListener('submit', handleFormSubmit);
    });
    
    function validateField(e) {
        const field = e.target;
        const value = field.value.trim();
        const fieldName = field.name;
        
        // Remove existing error
        clearError(e);
        
        // Validation rules
        let isValid = true;
        let errorMessage = '';
        
        if (field.hasAttribute('required') && !value) {
            isValid = false;
            errorMessage = `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
        } else if (fieldName === 'email' && value && !isValidEmail(value)) {
            isValid = false;
            errorMessage = 'Please enter a valid email address';
        }
        
        if (!isValid) {
            showError(field, errorMessage);
        }
    }
    
    function showError(field, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.textContent = message;
        errorDiv.style.color = '#ff4444';
        errorDiv.style.fontSize = '0.8rem';
        errorDiv.style.marginTop = '5px';
        errorDiv.style.animation = 'slideInRight 0.3s ease';
        
        field.parentElement.appendChild(errorDiv);
        field.style.borderColor = '#ff4444';
    }
    
    function clearError(e) {
        const field = e.target;
        const errorDiv = field.parentElement.querySelector('.field-error');
        
        if (errorDiv) {
            errorDiv.remove();
        }
        
        field.style.borderColor = '';
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function handleFormSubmit(e) {
        const form = e.target;
        const inputs = form.querySelectorAll('input, textarea, select');
        let isValid = true;
        
        // Clear any existing errors first
        inputs.forEach(input => {
            const errorDiv = input.parentElement.querySelector('.field-error');
            if (errorDiv) {
                errorDiv.remove();
            }
            input.style.borderColor = '';
        });
        
        inputs.forEach(input => {
            if (input.hasAttribute('required')) {
                validateField({ target: input });
                if (input.parentElement.querySelector('.field-error')) {
                    isValid = false;
                }
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            console.log('Form validation failed, preventing submission');
        } else {
            console.log('Form validation passed, allowing submission');
        }
    }
}

// Clean Interactive Effects
function initInteractiveEffects() {
    // Card hover effects with mouse tracking
    const cards = document.querySelectorAll('.nav-card, .feature-card, .event-card, .user-card, .stat-card, .ticket-card');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            card.style.setProperty('--mouse-x', (x / rect.width) * 100 + '%');
            card.style.setProperty('--mouse-y', (y / rect.height) * 100 + '%');
        });
        
        // Ripple effect on click
        card.addEventListener('click', createRipple);
    });
    
    // Button hover effects
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-2px) scale(1.02)';
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(0) scale(1)';
        });
        
        // Ripple effect on click
        button.addEventListener('click', createRipple);
    });
    
    function createRipple(e) {
        const ripple = document.createElement('span');
        const rect = e.currentTarget.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'rgba(0, 0, 0, 0.1)';
        ripple.style.transform = 'scale(0)';
        ripple.style.animation = 'ripple 0.6s linear';
        ripple.style.pointerEvents = 'none';
        
        e.currentTarget.style.position = 'relative';
        e.currentTarget.style.overflow = 'hidden';
        e.currentTarget.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }
}

// Clean Navigation
function initNavigation() {
    const nav = document.querySelector('nav');
    const navLinks = document.querySelectorAll('nav a');
    
    // Smooth scroll for anchor links
    navLinks.forEach(link => {
        if (link.getAttribute('href').startsWith('#')) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        }
    });
    
    // Navbar scroll effect
    let lastScrollTop = 0;
    window.addEventListener('scroll', () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scrolling down
            nav.style.transform = 'translateY(-100%)';
        } else {
            // Scrolling up
            nav.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;
    });
    
    // Mobile menu toggle (if exists)
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });
    }
}

// Clean Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Clean Event Listeners
window.addEventListener('resize', debounce(() => {
    // Handle responsive adjustments
    const cursorBubble = document.querySelector('.cursor-bubble');
    if (cursorBubble) {
        if (window.innerWidth <= 768) {
            cursorBubble.style.display = 'none';
        } else {
            cursorBubble.style.display = 'block';
        }
    }
}, 250));

// Clean Page Load Animation
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
    
    // Animate elements on page load
    const animatedElements = document.querySelectorAll('.hero-content, .page-header, .dashboard-header, .admin-header, .ticket-header');
    animatedElements.forEach((el, index) => {
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 200);
    });
});

// Clean CSS Animations
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(30px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    .loaded .hero-content,
    .loaded .page-header,
    .loaded .dashboard-header,
    .loaded .admin-header,
    .loaded .ticket-header {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease, transform 0.8s ease;
    }
    
    .focused input,
    .focused textarea,
    .focused select {
        border-color: var(--text-primary) !important;
        box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.1) !important;
    }
`;
document.head.appendChild(style); 