# Eventify Deployment Guide - PythonAnywhere

## Step 1: Sign up for PythonAnywhere

1. Go to [www.pythonanywhere.com](https://www.pythonanywhere.com)
2. Create a free account
3. Choose the "Beginner" plan (free)

## Step 2: Upload Your Code

### Option A: Using Git (Recommended)
1. In PythonAnywhere dashboard, go to "Consoles" → "Bash"
2. Clone your repository:
   ```bash
   git clone https://github.com/yourusername/eventify.git
   cd eventify
   ```

### Option B: Manual Upload
1. In PythonAnywhere dashboard, go to "Files"
2. Navigate to your home directory
3. Upload your project files

## Step 3: Set Up Virtual Environment

1. In the Bash console:
   ```bash
   cd eventify
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

## Step 4: Configure Web App

1. Go to "Web" tab in PythonAnywhere dashboard
2. Click "Add a new web app"
3. Choose "Manual configuration"
4. Select Python version (3.9 or higher)
5. Set source code to: `/home/yourusername/eventify`
6. Set working directory to: `/home/yourusername/eventify`

## Step 5: Configure WSGI File

1. In the "Web" tab, click on the WSGI configuration file
2. Replace the content with:

```python
import os
import sys

# Add your project directory to the sys.path
path = '/home/yourusername/eventify'
if path not in sys.path:
    sys.path.append(path)

# Set environment variable
os.environ['DJANGO_SETTINGS_MODULE'] = 'EM.settings_production'

# Import Django WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

## Step 6: Update Settings

1. Edit `EM/settings_production.py`
2. Replace `yourusername` with your actual PythonAnywhere username
3. Update `ALLOWED_HOSTS` with your domain

## Step 7: Set Up Database

1. In the Bash console:
   ```bash
   cd eventify
   source venv/bin/activate
   python manage.py migrate
   python manage.py collectstatic
   ```

## Step 8: Create Superuser (Optional)

```bash
python manage.py createsuperuser
```

## Step 9: Configure Email (Optional)

1. Update email settings in `settings_production.py`
2. Use your own email credentials

## Step 10: Reload Web App

1. Go to "Web" tab
2. Click "Reload" button
3. Your app should be live at: `yourusername.pythonanywhere.com`

## Troubleshooting

### Common Issues:

1. **Static files not loading:**
   - Run `python manage.py collectstatic`
   - Check static files configuration

2. **Database errors:**
   - Run `python manage.py migrate`
   - Check database settings

3. **Import errors:**
   - Make sure virtual environment is activated
   - Check all dependencies are installed

4. **Permission errors:**
   - Check file permissions
   - Make sure paths are correct

### Useful Commands:

```bash
# Check logs
tail -f /var/log/yourusername.pythonanywhere.com.error.log

# Check if app is running
ps aux | grep python

# Restart web app
touch /var/www/yourusername_pythonanywhere_com_wsgi.py
```

## Security Notes

1. Change `SECRET_KEY` in production
2. Use environment variables for sensitive data
3. Keep `DEBUG = False` in production
4. Regularly update dependencies

## Support

If you encounter issues:
1. Check PythonAnywhere error logs
2. Review Django documentation
3. Check PythonAnywhere help pages 